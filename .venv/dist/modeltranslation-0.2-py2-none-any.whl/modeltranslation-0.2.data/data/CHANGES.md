Changes
=======

Version 0.2
-------------

* Fixing dependencies. 


Version 0.1
-------------

* Basic django model translation support. 

